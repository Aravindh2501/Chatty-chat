import { useQuery } from "@tanstack/react-query";
import apiClient from "../api/apiInstance";
import { GET_MESSAGES } from "../api/endPoints";

const useFetchMessages = (currentUserId, selectedUserId) => {
  return useQuery({
    queryKey: ["messages", currentUserId, selectedUserId],
    queryFn: async () => {
      if (!currentUserId || !selectedUserId) return [];
      const res = await apiClient.get(
        `${GET_MESSAGES}/${currentUserId}?receiver=${selectedUserId}`
      );
      return res?.data?.messages || [];
    },
    enabled: !!currentUserId && !!selectedUserId,
    refetchOnWindowFocus: false,
    staleTime: 0,
    // Return empty array while loading so previous conversation data
    // never leaks into the new conversation's message list
    placeholderData: [],
    // Don't keep previous data when key changes (new conversation)
    keepPreviousData: false,
  });
};

export default useFetchMessages;
