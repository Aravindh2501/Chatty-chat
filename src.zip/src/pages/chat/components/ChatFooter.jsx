import {
  FaceSmileIcon,
  PaperAirplaneIcon,
  PhotoIcon,
  XCircleIcon,
  XMarkIcon,
  ArrowUturnLeftIcon,
} from "@heroicons/react/24/outline";
import { useState, useRef, useEffect } from "react";
import EmojiPicker from "emoji-picker-react";
import apiClient from "../../../api/apiInstance";
import { SEND_MSG } from "../../../api/endPoints";
import { useUserStore } from "../../../store/userStore";
import { useSocketStore } from "../../../store/useSocketStore";
import { useQueryClient } from "@tanstack/react-query";
import { compressImages } from "../../../utils/compressImage";
import toast from "react-hot-toast";

const ChatFooter = ({ SelectedUser, replyTo, onCancelReply }) => {
  const [text, setText] = useState("");
  const [media, setMedia] = useState([]);
  const [showEmoji, setShowEmoji] = useState(false);
  const [sending, setSending] = useState(false);

  const emojiRef = useRef(null);
  const fileRef = useRef(null);
  const inputRef = useRef(null);
  const typingTimer = useRef(null);

  const currentUser = useUserStore((state) => state.currentUser);
  const { startTyping, stopTyping, emitSendMessage, joinRoom, addMessage } =
    useSocketStore();
  const queryClient = useQueryClient();

  // Join socket room once for this conversation
  useEffect(() => {
    if (currentUser?._id && SelectedUser?.id) {
      joinRoom({ senderId: currentUser._id, receiverId: SelectedUser.id });
    }
  }, [currentUser?._id, SelectedUser?.id]);

  // Cleanup typing on unmount
  useEffect(() => {
    return () => {
      clearTimeout(typingTimer.current);
      if (currentUser?._id && SelectedUser?.id) {
        stopTyping({ senderId: currentUser._id, receiverId: SelectedUser.id });
      }
    };
  }, [currentUser?._id, SelectedUser?.id]);

  // Close emoji picker on outside click
  useEffect(() => {
    const handler = (e) => {
      if (emojiRef.current && !emojiRef.current.contains(e.target)) {
        setShowEmoji(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const handleTyping = (val) => {
    if (!currentUser?._id || !SelectedUser?.id) return;
    if (val.trim()) {
      startTyping({ senderId: currentUser._id, receiverId: SelectedUser.id });
      clearTimeout(typingTimer.current);
      typingTimer.current = setTimeout(() => {
        stopTyping({ senderId: currentUser._id, receiverId: SelectedUser.id });
      }, 1500);
    } else {
      clearTimeout(typingTimer.current);
      stopTyping({ senderId: currentUser._id, receiverId: SelectedUser.id });
    }
  };

  const onEmojiClick = (emoji) => {
    setText((prev) => prev + emoji.emoji);
    inputRef.current?.focus();
  };

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    setMedia((prev) => [
      ...prev,
      ...files.map((f) => ({ file: f, preview: URL.createObjectURL(f) })),
    ]);
    e.target.value = "";
  };

  const removeMedia = (idx) =>
    setMedia((prev) => prev.filter((_, i) => i !== idx));

  const handleSend = async () => {
    if (!text.trim() && media.length === 0) return;
    if (!currentUser?._id || !SelectedUser?.id) return;

    const textVal = text.trim();

    // Optimistic update — show message instantly with a temp id
    const optimisticMsg = {
      _id: `temp-${Date.now()}`,
      senderId: currentUser._id,
      receiverId: SelectedUser.id,
      text: textVal,
      type:
        media.length > 0
          ? media[0].file.type.startsWith("video")
            ? "video"
            : "image"
          : "text",
      content: media.map((m) => ({
        type: m.file.type.startsWith("video") ? "video" : "image",
        url: m.preview,
      })),
      status: "sent",
      createdAt: new Date().toISOString(),
      replyTo: replyTo || null,
      _optimistic: true,
    };

    addMessage(optimisticMsg);

    // Clear inputs immediately so UX feels fast
    setText("");
    setMedia([]);
    if (onCancelReply) onCancelReply();

    setSending(true);
    try {
      const formData = new FormData();
      formData.append("senderId", currentUser._id);
      formData.append("receiverId", SelectedUser.id);
      formData.append("text", textVal);
      formData.append(
        "type",
        optimisticMsg.type
      );
      if (replyTo) {
        formData.append("replyTo", replyTo._id || replyTo.messageId);
      }

      const rawFiles = media.map(({ file }) => file);
      const compressedFiles = await compressImages(rawFiles);
      compressedFiles.forEach((file) => formData.append("files", file));

      const res = await apiClient.post(SEND_MSG, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      const savedMsg = res.data.message;

      // Replace optimistic message with the real DB-saved message
      useSocketStore.setState((state) => ({
        messages: state.messages.map((m) =>
          m._id === optimisticMsg._id ? savedMsg : m
        ),
      }));

      // Broadcast to receiver via socket
      emitSendMessage(savedMsg);

      stopTyping({ senderId: currentUser._id, receiverId: SelectedUser.id });

      // Refresh sidebar conversation list
      queryClient.invalidateQueries({ queryKey: ["recentChats"] });
    } catch (err) {
      console.error("Send error:", err);
      // Remove optimistic message on failure
      useSocketStore.setState((state) => ({
        messages: state.messages.filter((m) => m._id !== optimisticMsg._id),
      }));
      toast.error("Failed to send message");
      // Restore text so user doesn't lose their message
      setText(textVal);
    } finally {
      setSending(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const canSend = !!(text.trim() || media.length > 0);

  return (
    <div className="border-t border-base-300 bg-base-200 rounded-b-xl">
      {/* Reply preview bar */}
      {replyTo && (
        <div className="flex items-center gap-2 px-4 py-2 border-b border-base-300 bg-base-300/50">
          <ArrowUturnLeftIcon className="w-4 h-4 text-primary flex-shrink-0" />
          <div className="flex-1 text-xs text-base-content/70 truncate">
            <span className="text-primary font-medium">Replying to: </span>
            {replyTo.type === "image" ? "📷 Photo" : replyTo.text}
          </div>
          <button
            onClick={onCancelReply}
            className="btn btn-ghost btn-xs btn-circle"
          >
            <XMarkIcon className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Media previews */}
      {media.length > 0 && (
        <div className="flex gap-2 flex-wrap px-4 pt-3">
          {media.map((item, idx) => (
            <div
              key={idx}
              className="relative w-16 h-16 rounded-xl overflow-hidden bg-base-300"
            >
              <img
                src={item.preview}
                alt="preview"
                className="w-full h-full object-cover"
              />
              <button
                className="absolute top-0.5 right-0.5 btn btn-circle btn-error btn-xs"
                onClick={() => removeMedia(idx)}
              >
                <XCircleIcon className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Input row */}
      <div className="flex items-center gap-2 px-3 py-2">
        {/* Emoji */}
        <div className="relative">
          <button
            className="btn btn-ghost btn-sm btn-circle"
            onClick={() => setShowEmoji(!showEmoji)}
            type="button"
          >
            <FaceSmileIcon className="w-5 h-5" />
          </button>
          {showEmoji && (
            <div ref={emojiRef} className="absolute bottom-12 left-0 z-30">
              <EmojiPicker
                onEmojiClick={onEmojiClick}
                height={350}
                width={300}
              />
            </div>
          )}
        </div>

        {/* Image/video upload */}
        <button
          className="btn btn-ghost btn-sm btn-circle"
          onClick={() => fileRef.current.click()}
          type="button"
        >
          <PhotoIcon className="w-5 h-5" />
        </button>
        <input
          hidden
          ref={fileRef}
          type="file"
          accept="image/*,video/*"
          multiple
          onChange={handleFileChange}
        />

        {/* Text input */}
        <input
          ref={inputRef}
          type="text"
          className="input input-bordered input-sm flex-1 bg-base-100 focus:outline-none"
          placeholder="Type a message..."
          value={text}
          onChange={(e) => {
            setText(e.target.value);
            handleTyping(e.target.value);
          }}
          onKeyDown={handleKeyDown}
        />

        {/* Send button */}
        <button
          className="btn btn-primary btn-sm btn-circle"
          onClick={handleSend}
          disabled={!canSend || sending}
          type="button"
        >
          {sending ? (
            <span className="loading loading-spinner loading-xs" />
          ) : (
            <PaperAirplaneIcon className="w-4 h-4" />
          )}
        </button>
      </div>
    </div>
  );
};

export default ChatFooter;
