import { useEffect, useRef } from "react";
import { useUserStore } from "../../../store/userStore";
import { useSocketStore } from "../../../store/useSocketStore";
import useFetchMessages from "../../../hooks/useFetchMessages";
import MessageBubble from "./MessageBubble";
import { DEFAULT_AVATAR } from "../../../content/data";

const MessageSkeleton = () => (
  <div className="flex flex-col gap-4 p-4">
    {[...Array(6)].map((_, i) => (
      <div
        key={i}
        className={`flex gap-3 ${i % 2 === 0 ? "justify-start" : "justify-end"}`}
      >
        {i % 2 === 0 && (
          <div className="w-8 h-8 rounded-full skeleton-shimmer flex-shrink-0" />
        )}
        <div className={`flex flex-col gap-1 ${i % 2 !== 0 ? "items-end" : ""}`}>
          <div
            className="h-10 rounded-2xl skeleton-shimmer"
            style={{ width: `${120 + (i * 30) % 120}px` }}
          />
          <div className="h-2 w-12 rounded skeleton-shimmer" />
        </div>
        {i % 2 !== 0 && (
          <div className="w-8 h-8 rounded-full skeleton-shimmer flex-shrink-0" />
        )}
      </div>
    ))}
  </div>
);

const MessageContainer = ({ SelectedUser, onReply }) => {
  const currentUser = useUserStore((state) => state.currentUser);
  const { messages, setMessages, isTyping, emitMarkRead } = useSocketStore();
  const messagesEndRef = useRef(null);

  // Track which user's messages are currently loaded to prevent stale cache bleed
  const loadedForRef = useRef(null);

  const { data: fetchedMessages, isLoading } = useFetchMessages(
    currentUser?._id,
    SelectedUser?.id
  );

  // Load fetched messages into store — but ONLY if they belong to the current conversation
  useEffect(() => {
    if (!fetchedMessages) return;
    // Guard: only apply if this is still the active conversation
    if (loadedForRef.current === SelectedUser?.id) {
      setMessages(fetchedMessages);
    }
  }, [fetchedMessages, SelectedUser?.id]);

  // When selected user changes, update the ref so we only apply correct messages
  useEffect(() => {
    loadedForRef.current = SelectedUser?.id || null;
  }, [SelectedUser?.id]);

  // Mark as read when conversation opens or changes
  useEffect(() => {
    if (currentUser?._id && SelectedUser?.id) {
      // senderId = the person whose messages we're reading (SelectedUser)
      // receiverId = us (currentUser) — we are now reading SelectedUser's messages
      emitMarkRead({
        senderId: SelectedUser.id,
        receiverId: currentUser._id,
      });
    }
  }, [SelectedUser?.id]);

  // Auto-scroll to bottom on new messages or typing indicator
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  if (isLoading) return <MessageSkeleton />;

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-1">
      {messages.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-full text-base-content/40 gap-3">
          <svg
            className="w-16 h-16 mb-1"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1}
              d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
            />
          </svg>
          <p className="text-sm font-medium">No messages yet</p>
          <p className="text-xs">Say hello to {SelectedUser?.username}!</p>
        </div>
      ) : (
        messages.map((msg, idx) => (
          <MessageBubble
            key={msg._id || msg.messageId || idx}
            message={msg}
            currentUser={currentUser}
            SelectedUser={SelectedUser}
            onReply={onReply}
          />
        ))
      )}

      {/* Typing indicator */}
      {isTyping && (
        <div className="flex items-center gap-2 mb-3">
          <img
            src={SelectedUser?.avatar || DEFAULT_AVATAR}
            alt="typing"
            className="w-7 h-7 rounded-full object-cover flex-shrink-0"
          />
          <div className="bg-base-300 rounded-tl-2xl rounded-tr-2xl rounded-br-2xl rounded-bl-none px-4 py-2">
            <div className="typing-loader text-base-content">
              <span />
              <span />
              <span />
            </div>
          </div>
        </div>
      )}

      <div ref={messagesEndRef} />
    </div>
  );
};

export default MessageContainer;
