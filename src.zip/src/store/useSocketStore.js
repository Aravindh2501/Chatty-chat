import { io } from "socket.io-client";
import { create } from "zustand";
import { useUserStore } from "./userStore";
import { markMessageAsDelivered } from "../services/messageService";
import { playAudioNotification } from "../utils/audioNotification";

const SOCKET_URL = import.meta.env.VITE_APP_SOCKET_URL || "";

export const useSocketStore = create((set, get) => ({
  socket: null,
  messages: [],
  onlineUsers: [],
  isTyping: false,
  // Tracks the currently open conversation partner's ID
  // so we can filter incoming messages correctly
  activeReceiverId: null,

  connectSocket: () => {
    const { currentUser, token } = useUserStore.getState();
    if (get().socket?.connected) return;

    const socket = io(SOCKET_URL, {
      transports: ["websocket"],
      withCredentials: true,
      reconnection: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
    });

    set({ socket });

    socket.on("connect", () => {
      console.log("Socket connected:", socket.id);
      if (currentUser?._id) {
        socket.emit("register_user", { userId: currentUser._id, token });
      }
    });

    socket.on("online_users", (userIds) => {
      set({ onlineUsers: userIds });
    });

    socket.on("user_offline", ({ userId, lastSeen }) => {
      set((state) => ({
        onlineUsers: state.onlineUsers.filter((id) => id !== userId),
      }));
    });

    socket.on("receive_message", (message) => {
      const { currentUser } = useUserStore.getState();
      const { activeReceiverId } = get();

      const msgSenderId =
        typeof message.senderId === "object"
          ? message.senderId?._id?.toString()
          : message.senderId?.toString();
      const msgReceiverId =
        typeof message.receiverId === "object"
          ? message.receiverId?._id?.toString()
          : message.receiverId?.toString();

      const myId = currentUser?._id?.toString();
      const activeId = activeReceiverId?.toString();

      const iAmSender = msgSenderId === myId;
      const iAmReceiver = msgReceiverId === myId;

      // Does this message belong to the currently open conversation?
      const belongsToActiveConv =
        activeId &&
        ((iAmSender && msgReceiverId === activeId) ||
         (iAmReceiver && msgSenderId === activeId));

      console.log("[socket] receive_message", {
        myId, activeId, msgSenderId, msgReceiverId,
        iAmSender, iAmReceiver, belongsToActiveConv,
        msgId: message._id,
      });

      if (iAmReceiver && !iAmSender) {
        // Someone sent me a message — mark delivered
        playAudioNotification();
        markMessageAsDelivered({
          messageId: message._id || message.messageId,
          status: "delivered",
        });
        // If it's not the open conversation, don't add to UI
        if (!belongsToActiveConv) return;
      }

      // For sender's bounced-back message: always update status tick (dedup handles no-duplicate)
      // For new incoming message in active conv: add to list
      set((state) => {
        const id = message._id || message.messageId;
        const exists = state.messages.some(
          (m) => (m._id && m._id === id) || (m.messageId && m.messageId === id)
        );
        if (exists) {
          return {
            messages: state.messages.map((m) =>
              (m._id && m._id === id) || (m.messageId && m.messageId === id)
                ? { ...m, status: message.status ?? m.status }
                : m
            ),
          };
        }
        // Brand new message — only add if it belongs to this conversation
        if (!belongsToActiveConv) return state;
        return { messages: [...state.messages, message] };
      });
    });

    // Individual tick update (delivered/read)
    socket.on("message_status_update", ({ messageId, status }) => {
      set((state) => ({
        messages: state.messages.map((msg) =>
          msg._id === messageId || msg.messageId === messageId
            ? { ...msg, status }
            : msg
        ),
      }));
    });

    socket.on("message_deleted", ({ messageId, isDeleted }) => {
      set((state) => ({
        messages: state.messages.map((msg) =>
          msg._id === messageId || msg.messageId === messageId
            ? { ...msg, isDeleted }
            : msg
        ),
      }));
    });

    // readBy = the person who READ (opened the chat and is receiving messages)
    // We update status to "read" for all messages we SENT to that person
    socket.on("messages_read", ({ readBy }) => {
      set((state) => ({
        messages: state.messages.map((msg) => {
          // A message was read: the reader (readBy) was the receiver of those messages
          const receiverId =
            typeof msg.receiverId === "object"
              ? msg.receiverId?._id
              : msg.receiverId;
          return receiverId === readBy ? { ...msg, status: "read" } : msg;
        }),
      }));
    });

    socket.on("receiver_typing", ({ senderId }) => {
      const { currentUser } = useUserStore.getState();
      if (senderId !== currentUser?._id) set({ isTyping: true });
    });

    socket.on("receiver_not_typing", ({ senderId }) => {
      const { currentUser } = useUserStore.getState();
      if (senderId !== currentUser?._id) set({ isTyping: false });
    });

    socket.on("disconnect", (reason) => {
      console.log("Socket disconnected:", reason);
      set({ isTyping: false });
    });

    socket.on("connect_error", (err) => {
      console.error("Socket connection error:", err.message);
    });
  },

  disconnectSocket: () => {
    const socket = get().socket;
    if (socket) {
      socket.removeAllListeners();
      socket.disconnect();
      set({
        socket: null,
        isTyping: false,
        messages: [],
        onlineUsers: [],
        activeReceiverId: null,
      });
    }
  },

  setActiveReceiver: (userId) => set({ activeReceiverId: userId }),

  setMessages: (messages) => set({ messages }),

  addMessage: (msgOrArray) => {
    if (Array.isArray(msgOrArray)) {
      set({ messages: msgOrArray });
    } else {
      set((state) => {
        const id = msgOrArray._id || msgOrArray.messageId;
        const exists = state.messages.some(
          (m) => (m._id && m._id === id) || (m.messageId && m.messageId === id)
        );
        if (exists) return state;
        return { messages: [...state.messages, msgOrArray] };
      });
    }
  },

  clearMessages: () => set({ messages: [], isTyping: false }),

  startTyping: ({ senderId, receiverId }) => {
    get().socket?.emit("start_typing", { senderId, receiverId });
  },

  stopTyping: ({ senderId, receiverId }) => {
    get().socket?.emit("stop_typing", { senderId, receiverId });
  },

  emitSendMessage: (data) => {
    get().socket?.emit("send_message", data);
  },

  emitDeleteMessage: (data) => {
    get().socket?.emit("delete_message", data);
  },

  emitMarkRead: ({ senderId, receiverId }) => {
    get().socket?.emit("mark_read", { senderId, receiverId });
  },

  joinRoom: ({ senderId, receiverId }) => {
    get().socket?.emit("join_room", { senderId, receiverId });
  },
}));